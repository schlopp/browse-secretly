function jekkrmoeder(){
  website = prompt("Enter a website\n('https://youtube.com', etc)")
  window.open(website, "", "width=1000,height=1000")
}